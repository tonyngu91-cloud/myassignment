package com.example.myapplication.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.Repository
import com.example.myapplication.data.local.SessionStore
import com.example.myapplication.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class LoginViewModel @Inject constructor(private val repo: Repository, private val session: SessionStore) : ViewModel() {
    private val _state = MutableStateFlow<UiState<Pair<String, String>>>(UiState.Idle)
    val state: StateFlow<UiState<Pair<String, String>>> = _state
    fun login(campus: String, username: String, password: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val keypass = repo.login(campus, username, password)
                session.save(keypass, campus)
                _state.value = UiState.Success(keypass to campus)
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Login failed")
            }
        }
    }
}