package com.example.myapplication.model

data class LoginResponse(val keypass: String)