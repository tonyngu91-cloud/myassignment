package com.example.myapplication.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.sessionDataStore by preferencesDataStore(name = "session")

@Singleton
class SessionStore @Inject constructor(@ApplicationContext context: Context) {
    private val dataStore = context.sessionDataStore

    companion object {
        private val KEY_KEYPASS = stringPreferencesKey("keypass")
        private val KEY_CAMPUS = stringPreferencesKey("campus")
    }

    val keypass: Flow<String?> = dataStore.data.map { it[KEY_KEYPASS] }
    val campus: Flow<String?> = dataStore.data.map { it[KEY_CAMPUS] }

    suspend fun save(keypass: String, campus: String) {
        dataStore.edit { prefs ->
            prefs[KEY_KEYPASS] = keypass
            prefs[KEY_CAMPUS] = campus
        }
    }

    suspend fun clear() {
        dataStore.edit { it.clear() }
    }
}