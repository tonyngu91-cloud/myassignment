package com.example.myapplication.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.ItemEntityBinding

class EntityAdapter(private val onClick: (Map<String, Any?>) -> Unit)
    : ListAdapter<Map<String, Any?>, EntityAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemEntityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) { holder.bind(getItem(position)) }

    inner class VH(private val b: ItemEntityBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(entity: Map<String, Any?>) {
            val filtered = entity.filterKeys { it.lowercase() != "description" }.toList()
            val line1 = filtered.getOrNull(0)?.let { "${it.first}: ${it.second}" } ?: "(item)"
            val line2 = filtered.getOrNull(1)?.let { "${it.first}: ${it.second}" } ?: ""
            b.tvLine1.text = line1
            b.tvLine2.text = line2
            b.root.setOnClickListener { onClick(entity) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Map<String, Any?>>() {
            override fun areItemsTheSame(o: Map<String, Any?>, n: Map<String, Any?>) = o == n
            override fun areContentsTheSame(o: Map<String, Any?>, n: Map<String, Any?>) = o == n
        }
    }
}