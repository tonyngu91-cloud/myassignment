package com.example.myapplication.data

import com.example.myapplication.data.remote.ApiService
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.model.LoginRequest
import javax.inject.Inject
import retrofit2.HttpException
import java.util.Locale

class Repository @Inject constructor(private val api: ApiService) {

    private fun slugifyCampus(raw: String): String =
        raw.trim().lowercase(Locale.ROOT).replace(" ", "-")

    suspend fun login(campus: String, username: String, password: String): String {
        val slug = slugifyCampus(campus)
        val body = LoginRequest(username, password)

        // Try /{campus}/auth first
        try {
            return api.loginCampusAuth(slug, body).keypass
        } catch (e: HttpException) {
            if (e.code() != 404) throw e
        }

        // Fallback to /auth/{campus}
        return api.loginAuthCampus(slug, body).keypass
    }

    suspend fun getDashboard(keypass: String): DashboardResponse = api.getDashboard(keypass)
}
