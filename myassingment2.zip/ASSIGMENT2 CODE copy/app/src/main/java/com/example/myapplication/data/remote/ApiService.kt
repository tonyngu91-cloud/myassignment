package com.example.myapplication.data.remote

import com.example.myapplication.model.LoginRequest
import com.example.myapplication.model.LoginResponse
import com.example.myapplication.model.DashboardResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    // Some servers expect /{campus}/auth, others /auth/{campus}.
    @POST("{campus}/auth")
    suspend fun loginCampusAuth(@Path("campus") campus: String, @Body body: LoginRequest): LoginResponse

    @POST("auth/{campus}")
    suspend fun loginAuthCampus(@Path("campus") campus: String, @Body body: LoginRequest): LoginResponse

    @GET("dashboard/{keypass}")
    suspend fun getDashboard(@Path("keypass") keypass: String): DashboardResponse
}
