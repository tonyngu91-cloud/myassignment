package com.example.myapplication.ui.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.myapplication.databinding.FragmentLoginBinding
import com.example.myapplication.util.UiState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private val vm: LoginViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val campuses = listOf("footscray", "sydney", "br")
        binding.spCampus.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, campuses)

        binding.btnLogin.setOnClickListener {
            binding.tvError.visibility = View.GONE
            val username = binding.etUsername.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            val campus = campuses[binding.spCampus.selectedItemPosition]
            vm.login(campus, username, password)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { state ->
                    when (state) {
                        is UiState.Idle -> binding.progress.visibility = View.GONE
                        is UiState.Loading -> binding.progress.visibility = View.VISIBLE
                        is UiState.Success -> {
                            binding.progress.visibility = View.GONE
                            val (keypass, campus) = state.data
                            val action = LoginFragmentDirections.actionLoginFragmentToDashboardFragment(keypass, campus)
                            findNavController().navigate(action)
                        }
                        is UiState.Error -> {
                            binding.progress.visibility = View.GONE
                            binding.tvError.text = state.message
                            binding.tvError.visibility = View.VISIBLE
                        }
                    }
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    private fun mapToFriendlyMessage(raw: String?): String =
        when {
            raw?.contains("404") == true -> "Login endpoint not found (404). Trying another campus or server path might help."
            raw?.contains("timeout", true) == true -> "Network timeout. Check your internet and try again."
            else -> raw ?: "Login failed"
        }

}
