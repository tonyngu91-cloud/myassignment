package com.example.myapplication.model

import com.squareup.moshi.Json

data class DashboardResponse(
    val entities: List<Map<String, Any?>>,
    @Json(name = "entityTotal") val entityTotal: Int
)