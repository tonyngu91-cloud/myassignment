package com.example.myapplication.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.Repository
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

@HiltViewModel
class DashboardViewModel @Inject constructor(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow<UiState<DashboardResponse>>(UiState.Loading)
    val state: StateFlow<UiState<DashboardResponse>> = _state
    fun load(keypass: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val res = repo.getDashboard(keypass)
                _state.value = if (res.entities.isEmpty()) UiState.Error("No items found") else UiState.Success(res)
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Failed to load dashboard")
            }
        }
    }
}