package com.example.myapplication.model

data class LoginRequest(val username: String, val password: String)