package com.example.myapplication
import com.example.myapplication.ui.MainActivity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        // Show welcome text
        val txtMessage = findViewById<TextView>(R.id.txtMessage)
        txtMessage.text = "Welcome to the Second Screen 🚀"

        // Back button → return to MainActivity
        val btnBack = findViewById<Button>(R.id.btnBack)
        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // optional: close this activity so it’s not left in the stack
        }
    }
}
